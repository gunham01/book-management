module.exports = {
    dbURI: 'mongodb://127.0.0.1:27017/library',
    secretkey: 'a44343f047e3bf7aeaa48245ba172ffb6023dfa63c6551cf53b0f9e1cd9d14ec',
}
